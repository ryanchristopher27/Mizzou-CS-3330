// Genre Enum File

package rdcb2fmoviess21;

/**
 * @author Ryan Christopher
 */
public enum Genre {
    ACTION, ANIMATION, COMEDY, DRAMA, FANTASY, HORROR, ROMANCE, SCI_FI, SUSPENSE, WESTERN, UNKNOWN;
}

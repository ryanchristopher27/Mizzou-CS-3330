/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rdcb2fmvctimerstopwatchfxmls21;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.util.Duration;

/**
 *
 * @author Ryan Christopher
 */
public abstract class AbstractModel {
    
//    public double secondsElapsed = 0;
//    private double tickTimeInSeconds = 0.01; // Used to change resolution
//    public double angleDeltaPerSeconds = 6;
    
//    private KeyFrame keyFrame;
    
//    Timeline timeline;
    
    public AbstractModel() {

        
    }
    
    
        
}

/*
 * Name: Ryan Christopher
 * Pawprint: rdcb2f
 * Class: CS 3330 Object Oriented Programming
 * Final Project: Movie List
 */
package rdcb2fmovielists21;

import javafx.event.ActionEvent;

/**
 *
 * @author Ryan Christopher
 */
public interface Switcher {
    public void goToA(ActionEvent event);
    public void goToB(ActionEvent event);
}
